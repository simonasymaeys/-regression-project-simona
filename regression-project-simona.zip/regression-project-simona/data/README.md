# Data folder

| File | Description |
|---|---|
| `ai_models_raw_epoch_ai.csv` | Raw snapshot of Epoch AI's "Data on AI Models" (`all_ai_models.csv`), downloaded 24 September 2026: 3,620 models x 57 columns. Source: https://epoch.ai/data/ai-models |
| `ai_training_energy_clean.csv` | Analysis-ready subset written by Step 3 of `notebooks/regression_capstone.ipynb`: 185 models with parameters, training compute, dataset size, training time and power draw all present, plus the derived `Energy_kWh` target and simplified `Domain_simple` / `Org_type` columns |
| `EPOCH_AI_LICENSE_README.md` | Epoch AI's licence and citation notice |

**Licence:** Creative Commons Attribution 4.0 (https://creativecommons.org/licenses/by/4.0/). Citation: Epoch AI, "Data on AI Models". Published online at epoch.ai. Retrieved from https://epoch.ai/data/ai-models.

**Refreshing the data:** if the raw CSV is missing, the notebook's loading cell downloads `https://epoch.ai/data/all_ai_models.csv` directly. A live download may contain more models than this snapshot, so results can differ slightly.
